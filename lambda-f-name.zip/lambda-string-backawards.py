import boto3

def {{lambda_name}}(event,context):
    print("received event")
    initial_string = "abcdefg"
    reversed_string = initial_string[::-1]
    return {
        'statusCode' : 200,
        'Original string': initial_string,
        'Reversed string': reversed_string
    }